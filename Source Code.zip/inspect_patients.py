import sqlite3

conn = sqlite3.connect("claimshield_storage.db")
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

print("=== PATIENTS ===")
cursor.execute("SELECT id, mrn, first_name, last_name, date_of_birth FROM patients")
for row in cursor.fetchall():
    print(dict(row))

conn.close()
