import sqlite3

conn = sqlite3.connect("claimshield_storage.db")
cursor = conn.cursor()

# Get all patient IDs currently in the database
cursor.execute("SELECT id FROM patients")
patient_ids = [row[0] for row in cursor.fetchall()]

# Realistic names to assign
names = [
    ("John", "Anderson"),
    ("Sarah", "Jenkins"),
    ("Robert", "Johnson"),
    ("Emily", "Davis"),
    ("Michael", "Miller"),
    ("Jessica", "Taylor"),
    ("David", "Thomas"),
    ("Linda", "Jackson"),
    ("James", "White"),
    ("Patricia", "Harris")
]

print("Updating existing patient records...")
for idx, p_id in enumerate(patient_ids):
    first, last = names[idx % len(names)]
    cursor.execute(
        "UPDATE patients SET first_name = ?, last_name = ? WHERE id = ?",
        (first, last, p_id)
    )
    print(f"Updated patient {p_id} to: {first} {last}")

conn.commit()
conn.close()
print("All patient names updated successfully.")
