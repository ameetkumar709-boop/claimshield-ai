import os
from pypdf import PdfReader

sample_docs_dir = r"c:\Users\AmeetKumarPanda\Documents\AI Docs\ClaimShield-AI\Sample Docs"
for file in os.listdir(sample_docs_dir):
    if file.endswith(".pdf"):
        path = os.path.join(sample_docs_dir, file)
        try:
            reader = PdfReader(path)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            print(f"\n=== File: {file} ===")
            for line in text.split("\n"):
                if "patient" in line.lower() or "name" in line.lower() or "first" in line.lower() or "last" in line.lower():
                    print(" ", line.strip())
        except Exception as e:
            print(f"Error reading {file}: {e}")
